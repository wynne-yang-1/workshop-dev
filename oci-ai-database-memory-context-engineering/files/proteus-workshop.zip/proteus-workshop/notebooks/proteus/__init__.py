"""
Proteus — SeerGroup Research Assistant
======================================
Memory-powered AI agent backed by Oracle AI Database 26ai.
"""

__version__ = "0.1.0"
